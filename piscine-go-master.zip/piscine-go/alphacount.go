package piscine

func AlphaCount(s string) int {
	letter := []rune(s)
	count := 0
	for _, i := range letter {
		if (i >= 65 && i <= 90) || (i >= 97 && i <= 122) {
			count = count + 1
		}
	}
	return count
}
