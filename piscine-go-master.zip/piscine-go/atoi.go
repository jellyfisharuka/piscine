package piscine

func Atoi(s string) int {
	result := 0
	sign := 1 // To store the sign of the number (1 for positive, -1 for negative)

	for i, char := range s {
		if char >= '0' && char <= '9' {
			digitValue := int(char - '0')
			result = result*10 + digitValue
		} else if i == 0 && (char == '-' || char == '+') {
			if char == '-' {
				sign = -1 // Set the sign to negative if the first character is '-'
			}
		} else {
			return 0 // Return 0 if the character is not a digit or an invalid sign
		}
	}

	return result * sign
}
