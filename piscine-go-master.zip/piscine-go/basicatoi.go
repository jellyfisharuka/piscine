package piscine

func BasicAtoi(s string) int {
	result := 0

	for _, char := range s {
		digitValue := int(char - '0')
		result = result*10 + digitValue
	}

	return result
}
