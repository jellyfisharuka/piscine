package main

import (
	"io/ioutil"
	"os"
)

func main() {
	data, err := ioutil.ReadAll(os.Stdin)
	if err != nil {
		os.Stderr.WriteString("ERROR: " + err.Error() + "\n")
		os.Exit(1)
	}
	os.Stdout.Write(data)
}
