package piscine

func Concat(str1 string, str2 string) string {
	result := str1 + str2
	return result
}
