package piscine

func ConcatParams(args []string) string {
	answer := ""
	leen := len(args)
	for i := 0; i < leen; i++ {
		if i != leen-1 {
			answer = answer + args[i] + "\n"
		} else {
			answer = answer + args[i]
		}
	}
	return answer
}
