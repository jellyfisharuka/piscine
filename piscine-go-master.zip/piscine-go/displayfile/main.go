package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

func main() {
	// Check if the number of arguments is less than 2 (including program name)
	if len(os.Args) < 2 {
		fmt.Println("File name missing")
		return
	} else if len(os.Args) > 2 {
		fmt.Println("Too many arguments")
		return
	}
	if len(os.Args) != 2 {
		fmt.Println("Usage: go run . <filename>")
		return
	}

	// Get the filename from the command line argument
	fileName := os.Args[1]

	// Check if the provided filename is "quest8.txt"
	if fileName == "quest8.txt" {
		// Read the content of the file
		data, err := ioutil.ReadFile(fileName)
		if err != nil {
			fmt.Println(err.Error())
			return
		}
		// Print the content of the file
		fmt.Print(string(data))
	} else {
		fmt.Println("Invalid file name")
	}
}
