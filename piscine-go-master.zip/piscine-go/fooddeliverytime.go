package piscine

import (
	"errors"
)

type food struct {
	preptime int
}

var menu = map[string]food{
	"burger":  {15},
	"chips":   {10},
	"nuggets": {12},
}

func FoodDeliveryTime(order string) (int, error) {
	totalTime := 0

	for _, item := range order {
		menuItem, exists := menu[string(item)]
		if !exists {
			return 0, errors.New("404 - Item not found in the menu")
		}
		totalTime += menuItem.preptime
	}

	return totalTime, nil
}
