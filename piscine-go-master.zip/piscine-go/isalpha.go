package piscine

func IsAlpha(str string) bool {
	value := []rune(str)
	check := true
	ln := 0
	for i := range value {
		ln = i
	}
	for i := 0; i <= ln; i++ {
		if (value[i] < 'A' || value[i] > 'Z') && (value[i] < 'a' || value[i] > 'z') && (value[i] < '0' || value[i] > '9') {
			check = false
			break
		}
	}
	return check
}
