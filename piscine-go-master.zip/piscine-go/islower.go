package piscine

func IsLower(s string) bool {
	value := []rune(s)
	ln := 0
	for i := range value {
		ln = i
	}
	for i := 0; i <= ln; i++ {
		if value[i] < 'a' || value[i] > 'z' {
			return false
		}
	}
	return true
}
