package piscine

func IsNumeric(s string) bool {
	leen := []rune(s)
	ln := 0
	check := true
	for i := range leen {
		ln = i
	}
	for i := 0; i <= ln; i++ {
		if leen[i] < '0' || leen[i] > '9' {
			check = false
			break
		}
	}
	return check
}
