package piscine

func IsPrintable(str string) bool {
	leen := []rune(str)
	ln := 0
	check := true
	for i := range leen {
		ln = i
	}
	for i := 0; i <= ln; i++ {
		if leen[i] < 32 {
			check = false
			break
		}
	}
	return check
}
