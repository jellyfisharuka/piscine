package piscine

func IsUpper(s string) bool {
	value := []rune(s)
	ln := 0
	for i := range value {
		ln = i
	}
	for i := 0; i <= ln; i++ {
		if value[i] < 'A' || value[i] > 'Z' {
			return false
		}
	}
	return true
}
