package piscine

func LastRune(s string) rune {
	runes := []rune(s)
	length := len(runes)
	return runes[length-1]
}
