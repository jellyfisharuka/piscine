
#!/bin/bash

# Use find to locate all files ending with .sh in the current directory and its sub-folders
# The '-type f' option ensures we only consider files, not directories.
# The '-name "*.sh"' option filters files with names ending in .sh
files=$(find . -type f -name "*.sh")

# Use awk to remove the .sh extension and print only the file names
file_names=$(echo "$files" | awk -F/ '{print $NF}' | sed 's/\.sh$//')

# Sort the file names in descending order
sorted_file_names=$(echo "$file_names" | sort -r)

# Print the sorted file names
echo "$sorted_file_names"