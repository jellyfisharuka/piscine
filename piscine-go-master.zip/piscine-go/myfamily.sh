#!/bin/bash      
      
      
      
       
      
      
      
      
       # Check if HERO_ID environment variable is set
      
      
      
      
       if [ -z "$HERO_ID" ]; then
      
      
      
      
         echo "HERO_ID environment variable is not set. Please set it with the subject's ID."
      
      
      
      
         exit 1
      
      
      
      
       fi
      
      
      
      
       
      
      
      
      
       # URL of the JSON file
      
      
      
      
       URL="https://01.alem.school/assets/superhero/all.json"
      
      
      
      
       
      
      
      
      
       # Fetch the JSON data using curl and extract the subject's family using jq
      
      
      
      
       FAMILY=$(curl -s $URL | jq --argjson id "$HERO_ID" '.[] | select(.id == $id) | .connections.relatives')
      
      
      
      
       
      
      
      
      
       # Remove quotes from the family string using bash parameter expansion
      
      
      
      
       FAMILY=${FAMILY//\"/}
      
      
      
      
       
      
      
      
      
       # Display the subject's family with newline characters
      
      
      
      
       echo "$FAMILY"

  
  
  
  