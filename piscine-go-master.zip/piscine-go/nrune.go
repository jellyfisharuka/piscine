package piscine

func NRune(s string, n int) rune {
	runes := []rune(s)
	for ind, varr := range runes {
		if ind == n-1 {
			return varr
		}
	}
	return 0
}
