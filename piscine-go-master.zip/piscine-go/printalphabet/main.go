package main

import "github.com/01-edu/z01"

func main() {
	for letter := 'a'; letter <= 'z'; letter++ {
		z01.PrintRune(letter) // Print each rune (character) in the loop
	}
	z01.PrintRune('\n') // Print a newline after printing the alphabet
}
