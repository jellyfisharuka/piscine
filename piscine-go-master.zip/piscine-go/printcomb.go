package piscine

import "github.com/01-edu/z01"

func PrintComb() {
	i := 0
	j := 0
	k := 0
	for i = 0; i <= 7; i++ {
		for j = 1 + i; j <= 8; j++ {
			for k = 1 + j; k <= 9; k++ {
				if i == 7 && j == 8 && k == 9 {
					z01.PrintRune(rune(i + '0'))
					z01.PrintRune(rune(j + '0'))
					z01.PrintRune(rune(k + '0'))
				} else {
					z01.PrintRune(rune(i + '0'))
					z01.PrintRune(rune(j + '0'))
					z01.PrintRune(rune(k + '0'))
					z01.PrintRune(',')
					z01.PrintRune(' ')

				}
			}
		}
	}
	z01.PrintRune('\n')
}
