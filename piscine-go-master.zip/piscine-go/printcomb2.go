package piscine

import "github.com/01-edu/z01"

func PrintComb2() {
	for i := '0'; i <= '9'; i++ {
		for j := '0'; j <= '9'; j++ {
			w := j + 1
			for z := i; z <= '9'; z++ {
				for x := w; x <= '9'; x++ {
					z01.PrintRune(i)
					z01.PrintRune(j)
					z01.PrintRune(' ')
					z01.PrintRune(z)
					z01.PrintRune(x)
					if !(i == '9' && j == '8' && z == '9') {
						z01.PrintRune(',')
						z01.PrintRune(' ')
					}
				}
				w = '0'
			}
		}
	}
	z01.PrintRune('\n')
}
