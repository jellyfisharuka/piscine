package main

import "github.com/01-edu/z01"

func main() {
	for digits := 0; digits <= 9; digits++ {
		digitRune := '0' + rune(digits)
		z01.PrintRune(digitRune)
	}
	z01.PrintRune('\n')
}
