package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	args := os.Args
	ln := len(args)
	for i := 1; i < ln; i++ {
		for _, j := range args[i] {
			z01.PrintRune(j)
		}
		z01.PrintRune('\n')
	}
}
