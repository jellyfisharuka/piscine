package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arg := os.Args[0]
	executableName := ""

	// Find the last '/' character in the path
	lastSlashIndex := -1
	for i := len(arg) - 1; i >= 0; i-- {
		if arg[i] == '/' {
			lastSlashIndex = i
			break
		}
	}

	// Extract the executable name
	if lastSlashIndex != -1 {
		executableName = arg[lastSlashIndex+1:]
	} else {
		executableName = arg
	}

	// Print the executable name
	for _, w := range executableName {
		z01.PrintRune(w)
	}
	z01.PrintRune('\n')
}
