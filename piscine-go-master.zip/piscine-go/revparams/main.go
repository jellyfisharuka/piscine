package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arg := os.Args
	ln := len(arg)
	for i := ln - 1; i > 0; i-- {
		for _, j := range arg[i] {
			z01.PrintRune(j)
		}
		z01.PrintRune('\n')
	}
}
