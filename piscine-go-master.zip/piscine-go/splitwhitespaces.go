package piscine

func SplitWhiteSpaces(s string) []string {
	var split []string

	word := ""

	for i := 0; i < len(s); i++ {
		if string(s[i]) == " " {
			if word != "" {
				split = append(split, word)
				word = ""
			}
		} else {
			word += string(s[i])
		}
		if i == len(s)-1 && word != "" {
			split = append(split, word)
		}
	}
	return split
}
