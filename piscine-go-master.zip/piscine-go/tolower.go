package piscine

func ToLower(s string) string {
	leen := []rune(s)
	for index, word := range leen {
		if word >= 'A' && word <= 'Z' {
			leen[index] = word + 32
		}
	}
	return string(leen)
}
