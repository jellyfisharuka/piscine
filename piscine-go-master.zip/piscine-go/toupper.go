package piscine

func ToUpper(s string) string {
	leen := []rune(s)
	for index, word := range leen {
		if word >= 'a' && word <= 'z' {
			leen[index] = word - 32
		}
	}
	return string(leen)
}
