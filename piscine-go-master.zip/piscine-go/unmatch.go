package piscine

func Unmatch(a []int) int {
	var count int
	for _, num1 := range a {
		count = 0
		for _, num2 := range a {
			if num1 == num2 {
				count++
			}
		}
		if count%2 != 0 {
			return num1
		}
	}
	return -1
}
